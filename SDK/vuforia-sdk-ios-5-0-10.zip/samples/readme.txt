Please download the sample apps at https://developer.vuforia.com/resources/sample-apps and unpack them in this folder
